//
//  MessageCatalog.m
//  Earthquake
//
//  Created by SREERAM SREENATH on 12/17/16.
//

#import "MessageCatalog.h"

@implementation MessageCatalog

@end

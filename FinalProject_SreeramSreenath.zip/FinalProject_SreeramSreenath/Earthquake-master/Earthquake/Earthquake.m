//
//  Earthquake.m
//  Earthquake
//
//
//  Created by SREERAM SREENATH on 12/08/16.
//

#import "Earthquake.h"

@implementation Earthquake

@end
